import { NotAvailablePipe } from './not-available.pipe';

describe('NotAvailablePipe', () => {
  it('create an instance', () => {
    const pipe = new NotAvailablePipe();
    expect(pipe).toBeTruthy();
  });
});
